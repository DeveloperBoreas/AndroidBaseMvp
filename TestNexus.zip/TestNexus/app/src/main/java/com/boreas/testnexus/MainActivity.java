package com.boreas.testnexus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.boreas.nexuslibary.AndroidPlugin;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AndroidPlugin androidPlugin = new AndroidPlugin();
    }
}
