package com.boreas.nexuslibary;

import android.util.Log;

public class AndroidPlugin {
    private static final String TAG = AndroidPlugin.class.getSimpleName();
    public void test(){
        Log.e(TAG,"aar 包测试成功");
    }
}
